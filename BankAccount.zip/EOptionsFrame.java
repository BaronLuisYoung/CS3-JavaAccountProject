import javax.swing.*;
import java.awt.event.*;

public class EOptionsFrame extends JFrame{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;
    private JMenu fileMenu, accountsMenu, transactionMenu;
    private JMenuItem  openFile, saveFile,
    addNewAccount, listAllTrans, listAllChecks, listAllDeposits, 
    listAllServiceCharges, findAnAccount, listAllAccounts, enterTransaction;
    private JMenuBar bar; 
    public EOptionsFrame(){

        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MenuListener ml = new MenuListener();
        //Creates File tab
        fileMenu = new JMenu("File");
        
        openFile = new JMenuItem("Open File");
        openFile.addActionListener(ml);
        fileMenu.add(openFile);

        saveFile = new JMenuItem("Save File");
        saveFile.addActionListener(ml);
        fileMenu.add(saveFile);
        
        //creates Accounts Tab
        accountsMenu = new JMenu("Accounts");

        addNewAccount = new JMenuItem("Add New Account");
        addNewAccount.addActionListener(ml);
        accountsMenu.add(addNewAccount);

        listAllTrans = new JMenuItem("List All Transactions");
        listAllTrans.addActionListener(ml);
        accountsMenu.add(listAllTrans);

        listAllChecks = new JMenuItem("List All Checks");
        listAllChecks.addActionListener(ml);
        accountsMenu.add(listAllChecks);

        listAllDeposits = new JMenuItem("List All Deposits");
        listAllDeposits.addActionListener(ml);
        accountsMenu.add(listAllDeposits);
        
        listAllServiceCharges = new JMenuItem("List All Service Charges");
        listAllServiceCharges.addActionListener(ml);
        accountsMenu.add(listAllServiceCharges);

        findAnAccount = new JMenuItem("Find An Account");
        findAnAccount.addActionListener(ml);
        accountsMenu.add(findAnAccount);

        listAllAccounts = new JMenuItem("List All Accounts");
        listAllAccounts.addActionListener(ml);
        accountsMenu.add(listAllAccounts);

        //Creates Transaction Tab
        transactionMenu = new JMenu("Transactions");
        
        enterTransaction = new JMenuItem("Enter Transaction");
        enterTransaction.addActionListener(ml);
        transactionMenu.add(enterTransaction);

        //create menu bar 
        bar = new JMenuBar();
        bar.add(fileMenu);
        bar.add(accountsMenu);
        bar.add(transactionMenu);
        setJMenuBar(bar);
    }

    private class MenuListener implements ActionListener{
        public void actionPerformed (ActionEvent event){
            String source = event.getActionCommand(); 
            try{
                if(source.equals("Open File")){
                    Main.OpenFile();
                }else if (source.equals("Save File")){
                    Main.saveCurrentFile();
                }else if (source.equals("Add New Account")){
                    Main.addAccount();
                }else if (source.equals("List All Transactions")){
                    Main.listTransactions();
                }else if (source.equals("List All Checks")){
                    Main.ListChecks();
                }else if (source.equals("List All Deposits")){
                    Main.ListDeposits();
                }else if (source.equals("List All Service Charges")){
                    Main.listAllServiceCharges();
                }else if (source.equals("Find An Account")){
                    Main.findAnAccount();
                }else if (source.equals("List All Accounts")){
                    Main.listAllAccounts();
                }
                else if(source.equals("Enter Transaction")){
                    Main.UserTransaction();
                }
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "You must select an account first");
            }
        }
    }
}
