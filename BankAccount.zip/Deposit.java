//deposit class that inherits from Transaction class
public class Deposit extends Transaction{
    private double cash;
    private double check;
    public Deposit(int tCount, int tId, double cashAmt, double checkAmt){
        super(tCount, tId, cashAmt+checkAmt);
        cash = cashAmt;
        check = checkAmt;
    }
    public double getCashAmt(){
        return cash;
    }
    public double getCheckAmnt(){
        return check;
    }
}
