import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/************************************************************************
************************************************************************/
//creates buttons and user interface 
public class UserOptionsPanel extends JPanel{
  private JLabel prompt; 
  private JRadioButton EnterTrans, ListTrans, ListChecks, ListDepos, OpenFile, SaveFile;
  
  public UserOptionsPanel(){
    //this.setLayout(layout);
    prompt = new JLabel("Choose Action:");
    prompt.setFont(new Font("Helvetica",Font.BOLD,24));
    EnterTrans = new JRadioButton("Enter Transaction");
    EnterTrans.setBackground(Color.green);
    ListTrans = new JRadioButton("List All Transactions");
    ListTrans.setBackground(Color.green);
    ListChecks = new JRadioButton("List All Checks");
    ListChecks.setBackground(Color.green);
    ListDepos  =  new JRadioButton("List All Deposits");
    ListDepos.setBackground(Color.green);
    OpenFile = new JRadioButton("Open File");
    OpenFile.setBackground(Color.green);
    SaveFile = new JRadioButton("Save File");
    SaveFile.setBackground(Color.green);
    ButtonGroup group = new ButtonGroup();
    
    group.add(EnterTrans);
    group.add(ListTrans);
    group.add(ListChecks);
    group.add(ListDepos);
    group.add(OpenFile);
    group.add(SaveFile);
    
    UserOptionsListener listener = new UserOptionsListener();
   
    EnterTrans.addActionListener(listener);
    ListTrans.addActionListener(listener);
    ListChecks.addActionListener(listener);
    ListDepos.addActionListener(listener);
    OpenFile.addActionListener(listener);
    SaveFile.addActionListener(listener);

    add(prompt);
    add(EnterTrans);
    add(ListTrans);
    add(ListChecks);
    add(ListDepos);
    add(OpenFile);
    add(SaveFile);

    setBackground(Color.green);
    setPreferredSize(new Dimension(400,100));
    }

    
    //*****************************************************************
    // listener for the radio buttons
    //*****************************************************************
    private class UserOptionsListener implements ActionListener{
        
        
        public void actionPerformed(ActionEvent e) {
            Object source = e.getSource();
            if(source == EnterTrans){
                Main.UserTransaction();
            }else if(source == ListTrans){
                Main.listTransactions();
            }else if (source == ListChecks){
                Main.ListChecks();
            }else if(source == ListDepos){
                Main.ListDeposits();
            }else if (source == OpenFile){
                    Main.OpenFile();
            }else if(source == SaveFile){ 
                Main.saveCurrentFile();
            }else{
                if(Main.saved == false){
                    Main.saveCurrentFile();
                }
            }
        }

    }

}
