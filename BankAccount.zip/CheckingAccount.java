import java.text.DecimalFormat;
import java.util.ArrayList;

//--------------------CheckingAccount.java ------------------------- 
public class CheckingAccount extends Account
{ 
   DecimalFormat fmt_1 = new DecimalFormat("$0.00");
   private double totalServiceCharge;
   // keeps a list of Transaction objects for the account 
   private ArrayList<Transaction> transList;  
   // the count of Transaction objects and used as the ID for each transaction 
   private int transCount;   
    // adds a transaction object to the transList
   public void addTrans(Transaction newTrans) {
      transCount++;
      transList.add(newTrans);
   }  
   //returns the current value of transCount; 
   public int getTransCount() {
      return transCount; 
   } 
 
   // returns the i-th Transaction object in the list
   public Transaction getTrans(int i){
      return transList.get(i);
   }  
   //constructor for checkingAccount
   public CheckingAccount(String accntName, double initialBalance) 
   {  
      super(accntName , initialBalance);
      balance = initialBalance; 
      transList = new ArrayList<>();
      totalServiceCharge = 0.0; 
   } 
   //returns balance of current account
   public double getBalance() 
   { 
      return balance; 
   } 
   //sets the balance based on the most recent transaction 
   public void setBalance(double transAmt, int tCode) 
   { 
      if(tCode == 1){
         balance = balance - transAmt; 
         setServiceCharge(0.15);
      }
      else if(tCode == 2){
         setServiceCharge(0.10);
         balance = balance + transAmt;
      }
   } 
   //returns the total amount of service charges to the account 
   public double getServiceCharge() 
   { 
      return totalServiceCharge; 
   } 
   //creates trasnsaction for the current service charge based on the transaction processed
   public void setServiceCharge(double currentServiceCharge) 
   { 
      Transaction serviceCharge = new Transaction(this.getTransCount(), 3, currentServiceCharge);
      transList.add(serviceCharge);
      totalServiceCharge = totalServiceCharge + currentServiceCharge; 
      transCount++;

   } 
   //unused toString method
   public String toString(){
      return null;
   }
   //If action button is clicked this lists all trasaction 
   public String AllTransactions(){
      String message ="";
      Transaction currTrans = null;
      for(int i=0; i < transCount; i++){
         currTrans = transList.get(i);
         if(currTrans.getTransId() == 1)
            message += "\n" + i + '\t' + "Check" + "     " + fmt_1.format(currTrans.getTransAmount());
         else if (currTrans.getTransId() == 2)
            message += "\n" + i + '\t' + "Deposit" +  "   " + fmt_1.format(currTrans.getTransAmount());
         else
            message += "\n" + i + '\t' + "Svc. Chg." + " " + fmt_1.format(currTrans.getTransAmount());
       }
      return message; 
   }
   //method to display all checks (money out)

   public String allServiceCharges(){
      String message ="";
      Transaction currTrans = null;
      for(int i = 0; i < transCount; i++){
         currTrans = transList.get(i);
         if(currTrans.getTransId() != 1 && currTrans.getTransId() != 2)
         message += "\n" + i + " \t" + fmt_1.format(currTrans.getTransAmount());
       }
      return message; 
   }

   public String AllChecks(){
      String message ="";
      Transaction currTrans = null;
      for(int i=0; i < transCount; i++){
         currTrans = transList.get(i);
         if(currTrans.getTransId() == 1)
            message += "\n" + i + "\t" + ((Check)currTrans).getCheckNumber() + "\t" + fmt_1.format(currTrans.getTransAmount());
       }
      return message; 
   }
   //method to display all deposits (money in)
   public String AllDeposits(){
      String message ="";
      Transaction currTrans = null;
      for(int i=0; i < transCount; i++){
         currTrans = transList.get(i);
         if(currTrans.getTransId() == 2)
            message += "\n" + i + "\t" + fmt_1.format(((Deposit)currTrans).getCashAmt()) + 
            "\t"  + fmt_1.format(((Deposit)currTrans).getCheckAmnt()) + '\t' + fmt_1.format(currTrans.getTransAmount());
       }
      return message; 
   }
   public ArrayList<Transaction> getTransList(){
      return transList;
   }
   public void clearAccount(){
      this.transList.clear();
      this.name = "";
      this.balance = 0.0;
      this.totalServiceCharge = 0.0;
      this.transCount = 0;
      //Main.initBalance();
   }
} 