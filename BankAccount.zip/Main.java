import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.text.DecimalFormat;
import java.util.Vector;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Main 
{  public static JTextArea ta;
   public static Vector<CheckingAccount> dataStore;
   public static String filename = "C:\\acct.dat";  // Default File location can be changed here  
   public static CheckingAccount account;
   public static DecimalFormat fmt_1 = new DecimalFormat("$0.00");
   public static JFrame frame_1;
   public static EOptionsFrame frame;
  
   public static JFrame deposit_frame;
   public static boolean  flag_Less_than_500 = false;
   public static boolean  flag_Less_than_0 = false;
   public static boolean saved = false; 
   public static int stateCount = 0;
   public static void main (String[] args) 
   {
      dataStore = new Vector<CheckingAccount>(5);
      createMenuInterface();
   }  
   //Processes the user input for each transaction, 
   //resonsible for adding propper messages to display window
   public static void UserTransaction(){
      String message = account.name + "'s Account" + '\n', message_final="";
      int transCode;
      double transAmt; 
        do{
         transCode = getTransCode();
        if(transCode == -1){return;}
        }
         while( 0 > transCode || transCode > 2);

         if(transCode == 0){
            message += "Transaction: End";
            if((account.getBalance() - account.getServiceCharge()) < 0 )
              message_final += "\n"+ "Final Balance: " + "("+ fmt_1.format(Math.abs(account.getBalance() - account.getServiceCharge())) + ')';
            else 
              message_final += "\n"+ "Final Balance: " + fmt_1.format(Math.abs(account.getBalance() - account.getServiceCharge()));
         }
         else{
            if(transCode == 1){
              String checkNumb_str = JOptionPane.showInputDialog("Enter your check number: ");
              int checkNumber = Integer.parseInt(checkNumb_str);
              transAmt = getTransAmt(1);
              message+= "Transaction: Check #" + checkNumb_str + " in Amount of " + fmt_1.format(transAmt);
              processCheck(transAmt, checkNumber);
            }else if(transCode == 2){
              transAmt = getTransAmt(2);
              processDeposit(transAmt);
              message += "Transaction: Deposit in amount of " + fmt_1.format(transAmt);
            }
         }

          if(account.getBalance() < 0)
            message += "\n"+ "Current Balance: " +  "(" + fmt_1.format(Math.abs(account.getBalance())) + ')';
          else 
          message += "\n"+ "Current Balance: " + fmt_1.format(Math.abs(account.getBalance()));

          if(transCode == 1)
            message+= "\n"+ "Service Charge: Check --- charge $0.15 ";
          else if(transCode == 2)
            message += "\n"+ "Service Charge: Deposit --- charge $0.10";

          if(flag_Less_than_500!= true && account.getBalance() < 500){
            flag_Less_than_500 = true; 
            message += "\n"+ "Service Charge: Below $500 --- charge $5.00";
            account.setServiceCharge(5);
          }
          if(account.getBalance() < 50 && transCode != 0){
            message += "\n"+ "Warning: Balance below $50";
          }
          if(account.getBalance() < 0 && transCode == 1){
            message += "\n"+ "Service Charge: Below $0 --- charge $10.00";
            account.setServiceCharge(10);
          }
            message += "\n"+ "Total Service Charge of: " + fmt_1.format(account.getServiceCharge());
            if(transCode == 0){
              message += message_final;
            }
            JOptionPane.showMessageDialog(null, message);
            message = "";
   }

   //gets the transaction code from user via input window
   public static int getTransCode() 
   { 
      String transCode = JOptionPane.showInputDialog("Enter your transaction code: ");
      if(transCode == null) return -1;
      return Integer.parseInt(transCode);
   } 
   //gets the transaction amount using transcode to determine what to add
   public static double getTransAmt(int transcode) 
   { 
      if(transcode == 1){
        String transAmt = JOptionPane.showInputDialog("Enter your check amount: ");
        return Double.parseDouble(transAmt);
      }
      else{
        double transAmt = getCheckAndCashAmnt();
        return transAmt;
      }
   } 
   //inputs check transaction if user enters code '1'
   public static void processCheck(double checkAmt, int checkNumber) 
   { 
      int tCount = account.getTransCount();
      Transaction NewlyOutputCheck = new Check(tCount, 1, checkAmt, checkNumber);
      account.addTrans(NewlyOutputCheck);
      account.setBalance(checkAmt, 1);
   } 
   
   //simply sets the balance of the account using deposit amount
   public static void processDeposit(double depositAmt) 
   { 
      account.setBalance(depositAmt, 2);
   } 

   //creates the checking account via users initial balance 
   public static void addAccount(){
    String initBalance;
    String accountName;
    if(account != null  && (saved == false || (stateCount != account.getTransCount()))){
      saveFile(filename);
    }
    accountName = JOptionPane.showInputDialog("Enter the account name: ");
    if (accountName == null){
      return;
    }
    initBalance = JOptionPane.showInputDialog("Enter your initial balance: ");
    if (initBalance == null){
      return;
    }
    double initial_balance = Double.parseDouble(initBalance);
    account = new CheckingAccount(accountName, initial_balance);
    dataStore.add(account);
    ta.setText("New account added for " + accountName);
   }
   
   //creates user option window for each action 
   public static void createInterface(){
    frame_1 = new JFrame();
    frame.addWindowListener(new java.awt.event.WindowAdapter(){
      @Override
      public void windowClosing(java.awt.event.WindowEvent windowEvent) {
        if(!saved || (stateCount != account.getTransCount())){
          int choice = (JOptionPane.showConfirmDialog(frame, 
              "The data in the application is not saved. \n Would you like to save it before exititng the application?", 
              "Select an Option?",  JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE));
          if (choice == JOptionPane.YES_OPTION){
              saveFile(filename);
              System.exit(0);
          }
          else if(choice == JOptionPane.NO_OPTION){
            System.exit(0);
          }else {
            createInterface();
          }
        }else{
          System.exit(0);
        }
      }
    });
    UserOptionsPanel panel = new UserOptionsPanel();
    frame.getContentPane().add(panel);
    frame.pack();
    frame.setVisible(true);
   }
   //if transcode '2' is entered, creates window for deposit transaction 
   // ash and check amounts are parsed new transaction element is created 
    public static double getCheckAndCashAmnt(){ 
      double cash = 0.0;
      double check = 0.0;
      double transAmt = 0.0;
      JTextField cash_feild = new JTextField(20);
      JTextField checks_feild = new JTextField(20);
      JPanel panel = new JPanel(new GridLayout(5,1));
      panel.add(new JLabel("Cash"));
      panel.add(cash_feild);
      panel.add(new JLabel("Checks"));
      panel.add(checks_feild);
      JOptionPane.showConfirmDialog(null, panel, "Deopsit Window", JOptionPane.OK_CANCEL_OPTION);
    
      if(!cash_feild.getText().isEmpty()){
        cash = Double.parseDouble(cash_feild.getText());
      }
      if(!checks_feild.getText().isEmpty()){
        check = Double.parseDouble(checks_feild.getText());
      }
        int tCount = account.getTransCount();
        Transaction NewlyInputCheckAndCash = new Deposit(tCount, 2, cash, check);
        account.addTrans(NewlyInputCheckAndCash);
        transAmt = cash + check; 
        return transAmt;
    }

    //helper function for listing desired transactions 
    public static String listMessageHelper(String message){ 
      String balance =  fmt_1.format(account.getBalance()); 
      if (account.getBalance() < 0){
        balance = '(' + fmt_1.format(Math.abs(account.getBalance())) + ')';
      }
      message = message +'\n' +"Name: " + account.name 
      + '\n' + "Balance: " + balance
      + '\n' + "Total Service Charge: " + fmt_1.format(account.getServiceCharge());
      return message;
    }
  //lists all the service charges to the account
    public static void listAllServiceCharges(){
      String message = listMessageHelper("List Service Charges");
      message +="\n\n" + "ID" + '\t' +"Amount"  + account.allServiceCharges(); 
      ta.setText(message);
     }
  //if action is chosen, lists all transactions input by user
   public static void listTransactions(){ 
    String message = listMessageHelper("List All Transactions");
    message += "\n\n" + "ID" + '\t' + "Type" + '\t' +"  Amount"  + account.AllTransactions();
    ta.setText(message);
   }
   
   //if action is chosen, list only check transaction input by user (money taken out)
   public static void ListChecks(){
    String message = listMessageHelper("List All Checks"); 
    message += "\n\n" + "ID" + '\t' +"Check" + '\t' +" Amount"  + account.AllChecks();
    ta.setText(message);
   }
   //if action is chosen, list only deposit transaction input by user (money put in)
   public static void ListDeposits(){
    String message = listMessageHelper("List All Deposits");
    message += "\n\n" +"ID" + '\t' + "Cash"+ '\t' + "Check" + '\t' + " Amount"  + account.AllDeposits(); 
    ta.setText(message);
   }

   public static void listAllAccounts(){
    String message = "List of All Accounts:" + "\n\n";
    for(int i = 0; i < dataStore.size(); i++){
      message += "Name: " + dataStore.get(i).name + '\n';
      if (dataStore.get(i).getBalance() < 0){
        message += "Balance: (" + Math.abs(dataStore.get(i).getBalance()) + ')'+ '\n';
      }else{
        message += "Balance: " + dataStore.get(i).getBalance() + '\n';
      }
        message +=  "Total Service Charge: " + dataStore.get(i).getServiceCharge() + "\n\n";
    }
    ta.setText(message);
   }

   //creates interface for choosing file 
   public static void OpenFile(){
    JFileChooser chooser = new JFileChooser();
    chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
    int status = chooser.showOpenDialog(null);
    if (status == JFileChooser.APPROVE_OPTION){   
      try {  
            File file = chooser.getSelectedFile();
            filename = file.getPath();
            ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(filename));
            account = (CheckingAccount)objectInputStream.readObject();
            dataStore.add(account);
            stateCount = account.getTransCount();
            objectInputStream.close();
        }catch (Exception e){
            System.out.println(e);
        }
      }     
   }
   //searches for an account that user queries 
   public static void findAnAccount(){
    String query = JOptionPane.showInputDialog("Enter the account name: ");
    if (query == null){
      return;
    }
    String message = "";
    for(int i = 0; i < dataStore.size(); i++){
      if(dataStore.get(i).getName().equals(query)){
        message += "Found account for " + query;
        account = dataStore.get(i);
      }
    }
    if(message == ""){
      ta.setText("Account not found for " + query);
    }else{
      ta.setText(message);
    }   
   }

  //determines if file has been saved, prompts user to saves current file if not already saved 
  public static void saveCurrentFile(){
    if(account != null){
      String currentPath = filename;
      JLabel label1 = new JLabel("Would you like to use the current default file: \n" + currentPath);      
      int confirm = JOptionPane.showConfirmDialog(null, label1, "Select an option ", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
      if(confirm == JOptionPane.YES_OPTION){
          saveFile(currentPath);
      }else if (confirm == JOptionPane.NO_OPTION){  
          JFileChooser fc = new JFileChooser();
          int status = fc.showSaveDialog(null);
          if (status == JFileChooser.APPROVE_OPTION){
            try {  
              File file = fc.getSelectedFile();
                filename = file.getPath();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(filename));
                objectOutputStream.writeObject(account);
                objectOutputStream.close();
            }catch (Exception e){
              System.out.println(e);
            }
        }
      }
    }else{
      JOptionPane.showMessageDialog(null, "You must select an account first");
    }
  }
//writes current account data to newly created file (saves the current file state)
  public static void saveFile(String currentPath){
    try{
        File file = new File(currentPath);
        if(!file.exists()){
            file.createNewFile();
        }                                
        FileOutputStream fout = new FileOutputStream(currentPath);
        ObjectOutputStream out = new ObjectOutputStream(fout);
        out.writeObject(account);
        out.close();
        Main.saved = true;
      }catch(IOException e_1Exception){
          System.out.println(e_1Exception);
      }
  }
  //creates menu window with text area 
  public static void createMenuInterface(){
    frame = new EOptionsFrame();
    frame.addWindowListener(new java.awt.event.WindowAdapter(){
      @Override
      public void windowClosing(java.awt.event.WindowEvent windowEvent) {
        if((stateCount != account.getTransCount()) && (account != null)){
          int choice = (JOptionPane.showConfirmDialog(frame, 
              "The data in the application is not saved. \n Would you like to save it before exititng the application?", 
              "Select an Option?",  JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE));
          if (choice == JOptionPane.YES_OPTION){
              saveCurrentFile();
              System.exit(0);
          }
          else if(choice == JOptionPane.NO_OPTION){
            System.exit(0);
          }
          else
          {
             createMenuInterface();
          }
        }else{
          System.exit(0);
        }
      }
    });
    ta = new JTextArea(10,50);
    ta.setFont(new Font("Monospaced", Font.PLAIN, 12));
    
    frame.getContentPane().add(ta);
    frame.pack();
    frame.setVisible(true);
  }
}

